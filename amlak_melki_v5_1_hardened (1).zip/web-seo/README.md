# نسخه وب SEO — V4
این پوشه قرارداد صفحات SEO را مشخص می‌کند. پیاده‌سازی نهایی SSR را می‌توان با Next.js انجام داد.
صفحات اصلی:
- /
- /buy
- /rent
- /properties/[id]
- /city/[city]
- /category/[category]
برای هر ملک: title، meta description، canonical، OpenGraph، JSON-LD، sitemap و robots.
