const express=require("express");
const cors=require("cors");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const multer=require("multer");
const {Pool}=require("pg");
const path=require("path");
const fs=require("fs");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_ME";
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const uploadDir=path.join(__dirname,"../uploads");
fs.mkdirSync(uploadDir,{recursive:true});

app.use(cors());
app.use(express.json({limit:"2mb"}));
app.use("/uploads",express.static(uploadDir));
app.use("/admin",express.static(path.join(__dirname,"../../admin")));

async function auth(req,res,next){
 const h=req.headers.authorization||"";
 if(!h.startsWith("Bearer ")) return res.status(401).json({error:"نیاز به ورود"});
 try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next();}
 catch(e){res.status(401).json({error:"توکن نامعتبر"});}
}
function admin(req,res,next){if(req.user?.role!=="admin")return res.status(403).json({error:"دسترسی مدیر لازم است"});next();}

app.get("/api/health",async(req,res)=>{
 try{await pool.query("SELECT 1");res.json({ok:true,db:true,version:"v4"});}
 catch(e){res.status(503).json({ok:false,db:false,error:"database unavailable"});}
});

app.post("/api/auth/register",async(req,res)=>{
 try{
  const {name="",email,password,phone=""}=req.body||{};
  if(!email||!password||password.length<6)return res.status(400).json({error:"ایمیل و رمز حداقل ۶ کاراکتری الزامی است"});
  const exists=await pool.query("SELECT id FROM users WHERE lower(email)=lower($1)",[email]);
  if(exists.rowCount)return res.status(409).json({error:"ایمیل قبلا ثبت شده است"});
  const hash=await bcrypt.hash(password,12);
  const r=await pool.query("INSERT INTO users(name,email,password_hash,phone) VALUES($1,$2,$3,$4) RETURNING id,name,email,phone,role",[name,email,hash,phone]);
  const u=r.rows[0], token=jwt.sign({id:u.id,email:u.email,role:u.role},JWT_SECRET,{expiresIn:"7d"});
  res.status(201).json({token,user:u});
 }catch(e){res.status(500).json({error:"خطای سرور"});}
});

app.post("/api/auth/login",async(req,res)=>{
 try{
  const {email,password}=req.body||{};
  const r=await pool.query("SELECT id,name,email,password_hash,phone,role FROM users WHERE lower(email)=lower($1)",[email]);
  if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash)))return res.status(401).json({error:"ایمیل یا رمز عبور اشتباه است"});
  const u=r.rows[0];delete u.password_hash;
  const token=jwt.sign({id:u.id,email:u.email,role:u.role},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:u});
 }catch(e){res.status(500).json({error:"خطای سرور"});}
});

app.get("/api/me",auth,async(req,res)=>{
 const r=await pool.query("SELECT id,name,email,phone,role,created_at FROM users WHERE id=$1",[req.user.id]);
 if(!r.rowCount)return res.status(404).json({error:"کاربر پیدا نشد"});
 res.json({user:r.rows[0]});
});

app.get("/api/properties",async(req,res)=>{
 const q=(req.query.q||"").trim();
 const r=q
 ? await pool.query(`SELECT id,title,city,neighborhood,type,price,area,phone,description,images,status,created_at
   FROM properties WHERE status='approved' AND to_tsvector('simple',coalesce(title,'')||' '||coalesce(city,'')||' '||coalesce(neighborhood,'')||' '||coalesce(description,'')) @@ plainto_tsquery('simple',$1)
   ORDER BY created_at DESC`,[q])
 : await pool.query(`SELECT id,title,city,neighborhood,type,price,area,phone,description,images,status,created_at FROM properties WHERE status='approved' ORDER BY created_at DESC`);
 res.json({properties:r.rows});
});

app.post("/api/properties",auth,async(req,res)=>{
 const p=req.body||{};
 if(!p.title||!p.city)return res.status(400).json({error:"عنوان و شهر الزامی است"});
 const r=await pool.query(`INSERT INTO properties(owner_id,title,city,neighborhood,type,price,area,phone,description,status)
 VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending') RETURNING *`,
 [req.user.id,p.title,p.city,p.neighborhood||"",p.type||"فروش",p.price||"",p.area||"",p.phone||"",p.description||""]);
 res.status(201).json({property:r.rows[0]});
});

const upload=multer({storage:multer.diskStorage({
 destination:(req,file,cb)=>cb(null,uploadDir),
 filename:(req,file,cb)=>cb(null,Date.now()+"-"+Math.random().toString(36).slice(2)+path.extname(file.originalname))
}),limits:{fileSize:8*1024*1024}});

app.post("/api/properties/:id/images",auth,upload.array("images",10),async(req,res)=>{
 const files=(req.files||[]).map(f=>"/uploads/"+f.filename);
 const owner=await pool.query("SELECT owner_id FROM properties WHERE id=$1",[req.params.id]);
 if(!owner.rowCount)return res.status(404).json({error:"آگهی پیدا نشد"});
 if(owner.rows[0].owner_id!==req.user.id && req.user.role!=="admin")return res.status(403).json({error:"دسترسی ندارید"});
 const r=await pool.query("UPDATE properties SET images=COALESCE(images,'[]'::jsonb) || $1::jsonb, updated_at=now() WHERE id=$2 RETURNING images",
   [JSON.stringify(files),req.params.id]);
 res.json({images:r.rows[0].images});
});

app.post("/api/upload",auth,upload.array("images",10),async(req,res)=>{
 res.json({images:(req.files||[]).map(f=>"/uploads/"+f.filename)});
});

app.post("/api/properties/:id/approve",auth,admin,async(req,res)=>{
 const r=await pool.query("UPDATE properties SET status='approved',updated_at=now() WHERE id=$1 RETURNING *",[req.params.id]);
 if(!r.rowCount)return res.status(404).json({error:"آگهی پیدا نشد"});
 res.json({property:r.rows[0]});
});

app.post("/api/properties/:id/reject",auth,admin,async(req,res)=>{
 const r=await pool.query("UPDATE properties SET status='rejected',updated_at=now() WHERE id=$1 RETURNING *",[req.params.id]);
 if(!r.rowCount)return res.status(404).json({error:"آگهی پیدا نشد"});
 res.json({property:r.rows[0]});
});

app.get("/api/admin/properties",auth,admin,async(req,res)=>{
 const r=await pool.query(`SELECT p.*,u.name owner_name,u.email owner_email FROM properties p JOIN users u ON u.id=p.owner_id ORDER BY p.created_at DESC`);
 res.json({properties:r.rows});
});

app.get("/api/my/properties",auth,async(req,res)=>{
 const r=await pool.query("SELECT * FROM properties WHERE owner_id=$1 ORDER BY created_at DESC",[req.user.id]);
 res.json({properties:r.rows});
});

app.post("/api/properties/:id/favorite",auth,async(req,res)=>{
 try{
  await pool.query("INSERT INTO favorites(user_id,property_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[req.user.id,req.params.id]);
  res.json({favorite:true});
 }catch(e){res.status(500).json({error:"خطای ثبت علاقه‌مندی"});}
});

app.delete("/api/properties/:id/favorite",auth,async(req,res)=>{
 await pool.query("DELETE FROM favorites WHERE user_id=$1 AND property_id=$2",[req.user.id,req.params.id]);
 res.json({favorite:false});
});

app.get("/api/favorites",auth,async(req,res)=>{
 const r=await pool.query(`SELECT p.* FROM properties p JOIN favorites f ON f.property_id=p.id
   WHERE f.user_id=$1 ORDER BY f.created_at DESC`,[req.user.id]);
 res.json({properties:r.rows});
});

app.delete("/api/properties/:id",auth,async(req,res)=>{
 const r=await pool.query("DELETE FROM properties WHERE id=$1 AND (owner_id=$2 OR $3='admin') RETURNING id",[req.params.id,req.user.id,req.user.role]);
 if(!r.rowCount)return res.status(403).json({error:"دسترسی ندارید یا آگهی وجود ندارد"});
 res.json({deleted:r.rows[0].id});
});

app.listen(PORT,()=>console.log("Amlak Melki V4 API on "+PORT));
